package com.atguigu.mapper;

import com.atguigu.bean.Admin;

import java.util.List;

/*************************************************
 时间: 2022-05-16
 讲师: 刘  辉
 出品: 尚硅谷教学团队
 **************************************************/
public interface AdminMapper {

    public List<Admin> getAdminList();
}

package com.atguigu.app;

/*====================================================
                时间: 2022-06-17
                讲师: 刘  辉
                出品: 尚硅谷讲师团队
======================================================*/
public class MainClass {
    public static void main(String[] args) {
        System.out.println("执行了");
    }
}

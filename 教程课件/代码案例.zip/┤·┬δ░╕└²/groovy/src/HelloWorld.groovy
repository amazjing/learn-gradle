class HelloWorld1 {

   def  username=''

   public def getUsername(){
       "哈哈"
    }
}
def ds=new HelloWorld1().getUsername
//print(ds)




package com.atguigu.groovy

class Actor {
    def age;
    String name;
    boolean  gender;


    //这是单行注释
    /**
     * 这是多行注释
     */
    public def  getUsername(){

    }
}

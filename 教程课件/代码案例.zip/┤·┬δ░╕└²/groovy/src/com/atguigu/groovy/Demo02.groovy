package com.atguigu.groovy

def username="张三丰"
println(username)

class Demo03{

}
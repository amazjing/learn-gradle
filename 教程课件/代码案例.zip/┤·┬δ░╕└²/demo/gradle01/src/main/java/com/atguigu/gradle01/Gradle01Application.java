package com.atguigu.gradle01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Gradle01Application {

	public static void main(String[] args) {
		SpringApplication.run(Gradle01Application.class, args);
	}

}

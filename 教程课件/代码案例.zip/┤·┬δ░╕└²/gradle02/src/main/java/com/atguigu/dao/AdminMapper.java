package com.atguigu.dao;

import com.atguigu.bean.Admin;

import java.util.List;

public interface AdminMapper {
    List<Admin> getAdminList();
}

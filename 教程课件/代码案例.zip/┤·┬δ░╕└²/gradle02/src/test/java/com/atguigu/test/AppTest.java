package com.atguigu.test;

import com.atguigu.controller.AdminController;


import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/*====================================================
                时间: 2022-06-16
                讲师: 刘  辉
                出品: 尚硅谷讲师团队
======================================================*/

public class AppTest {

    @Test
    public void testMethod1(){
        System.out.println("test atguigu method1");
    }
}

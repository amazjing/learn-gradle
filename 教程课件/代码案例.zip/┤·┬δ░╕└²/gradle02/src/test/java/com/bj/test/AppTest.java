package com.bj.test;


import org.junit.jupiter.api.Test;

public class AppTest {



    @Test
    public void testMethod1(){
        System.out.println("test bj method1");
    }
}
